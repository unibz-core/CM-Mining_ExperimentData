? Select relations to filter-out:  done
Deleted nodes (relations): ['derivation']
? Select edges to filter-out:  done (4 selections)
Deleted edges: ['isComplete', 'isDisjoint', 'generalization', 'restrictedTo']
? Enter the min_support value  3
? Enter the min_num_vertices  8
Selected values: [3, 8]
Function execution timed out
? Stop the process?  (y/N)
? Do you want to filter out known patterns? (yes/no)  y
? Enter the similarity threshold (between 0 and 1):  0.8