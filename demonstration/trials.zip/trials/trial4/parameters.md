? Select relations to filter-out:  done
Deleted nodes (relations): ['derivation']
? Select edges to filter-out:  done (5 selections)
Deleted edges: ['cardinalities', 'isComplete', 'isDisjoint', 'generalization', 'restrictedTo']
? Enter the min_support value  6
? Enter the min_num_vertices  4
Selected values: [6, 4]
Function execution timed out
? Stop the process?  No
? Do you want to filter out known patterns? (yes/no)  y
? Enter the similarity threshold (between 0 and 1):  0.9