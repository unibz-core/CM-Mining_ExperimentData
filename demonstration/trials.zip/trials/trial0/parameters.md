? Select classes to filter-out:  [class]
Deleted nodes (classes): ['class']
? Select relations to filter-out:  done
Deleted nodes (relations): ['derivation']
? Select edges to filter-out:  done (4 selections)
Deleted edges: ['isComplete', 'isDisjoint', 'generalization', 'restrictedTo']
? Enter the min_support value  8
? Enter the min_num_vertices  6
Selected values: [8, 6]
? Stop the process?  No
? Do you want to filter out known patterns? (yes/no)  n
? Enter the similarity threshold (between 0 and 1):  0.5