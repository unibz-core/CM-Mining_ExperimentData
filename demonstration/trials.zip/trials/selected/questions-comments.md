###for each pattern:
ask if it is interesting [very interesting, interesting, not very interesting]
ask if it is actionable [yes, no]. If yes, ask how it could be used
ask for comments/suggestions 

####for the whole experience
ask whether the visualization was useful
ask whether the example occurrences were useful
ask for comments/suggestions

####comments
pattern index 107, should be arleady discussed by a paper from Gian et al. ask.
pattern index 28 is interesting to be discussed, check how